# Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.

How to install the Oracle JME-E Virtual COM Port driver:

1) Modify setting in the Java's configuration files (KEIL board's only related changes):
    -- platform.cfg: set watchdog.enable = false
    -- jwc_prop.ini: set log.method = USBCOM

2) Connect your the board through USBFS port to your Windows based machine using micro USB cable

3) On some Windows platform (ex. Windows XP) "New Hardware Wizard" can launch automatically and ask you to specify
   a way you would like to use to install the driver. Press "Cancel" button in such cases.
   (In some cases the "New Hardware Wizard" window can appear twice, in both cases press the "Cancel" button).

4) After the "New Hardware Wizard" is dismissed or if it doesn't appear at all, launch an appropriate
   Oracle JME-E Virtual COM Port driver installer:
    -- oracle_jmee_cdc_v1.0_setup_x86.exe have to be used for x86 platforms
    -- oracle_jmee_cdc_v1.0_setup_x64.exe have to be used for x64 platforms
    -- oracle_jmee_cdc_v1.0_setup_ia64.exe have to be used for 64 bit Intel Itanium platforms

5) During the installation the wizard will warn you that the driver is not signed and that it is delivered from an
   unchecked publisher. Ignore this warning pressing the "Continue" button.

6) Now the the board is ready to be used in the USB logging mode.

Troubleshooting:
-- On a Windows 7 64 bit machine Device Manager can complain that there are some issues with
   "Oracle JME-E Virtual COM Port" device after the driver has been installed. It occurs only for the first time
   after driver's installation. To resolve the issue the board has to be restarted.