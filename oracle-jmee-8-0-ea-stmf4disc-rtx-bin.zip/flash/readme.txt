# Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.

How to flash the firmware to the target.
- Open 'flash.bat' and edit the path of MDK Tools.
- Verify if 'JavaVM.axf' exists in the same folder.
- Run 'flash.bat'
- After complete, Open the log file(output.txt) to check if it was programmed properly.
